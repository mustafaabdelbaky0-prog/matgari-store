const db = require('../lib/db');
const { hashPassword, verifyPassword, createSession, destroySession, uniqueSlug, setCookie, parseCookies } = require('../lib/auth');
const { page, esc, CATEGORIES } = require('../lib/view');
const { parseBody } = require('../lib/body');
const { sendHtml, redirect } = require('../lib/http-helpers');

function authLayout({ title, subtitle, body, error, success }) {
  return page({
    title,
    body: `
    <div class="auth-wrap">
      <div class="auth-card">
        <div class="auth-logo">🛍️</div>
        <div class="auth-title">${esc(title)}</div>
        <div class="auth-sub">${esc(subtitle)}</div>
        <div class="card">
          ${error ? `<div class="error-box">${esc(error)}</div>` : ''}
          ${success ? `<div class="success-box">${esc(success)}</div>` : ''}
          ${body}
        </div>
      </div>
    </div>`,
  });
}

function registerRoutes(router) {
  // ---------- تسجيل حساب جديد ----------
  router.get('/register', (req, res) => {
    sendHtml(res, 200, authLayout({
      title: 'ابدأ متجرك',
      subtitle: 'سجّل بياناتك عشان تبدأ تدير مبيعاتك في دقيقة',
      body: `
      <form method="POST" action="/register">
        <div class="field">
          <label>اسمك</label>
          <input type="text" name="name" required placeholder="مثال: أحمد محمد">
        </div>
        <div class="field">
          <label>اسم المتجر</label>
          <input type="text" name="store_name" required placeholder="مثال: متجر لمسة">
        </div>
        <div class="field">
          <label>رقم الموبايل</label>
          <input type="tel" name="phone" required placeholder="01xxxxxxxxx">
        </div>
        <div class="field">
          <label>كلمة المرور</label>
          <input type="password" name="password" required minlength="4" placeholder="6 أحرف أو أكتر">
        </div>
        <button class="btn btn-primary" type="submit">إنشاء الحساب</button>
      </form>
      <div class="auth-switch">عندك حساب بالفعل؟ <a href="/login">تسجيل الدخول</a></div>
      `,
    }));
  });

  router.post('/register', async (req, res) => {
    const b = await parseBody(req);
    const name = (b.name || '').trim();
    const storeName = (b.store_name || '').trim();
    const phone = (b.phone || '').trim();
    const password = (b.password || '').trim();

    const fail = (msg) => sendHtml(res, 400, authLayout({
      title: 'ابدأ متجرك',
      subtitle: 'سجّل بياناتك عشان تبدأ تدير مبيعاتك في دقيقة',
      error: msg,
      body: `
      <form method="POST" action="/register">
        <div class="field"><label>اسمك</label><input type="text" name="name" required value="${esc(name)}"></div>
        <div class="field"><label>اسم المتجر</label><input type="text" name="store_name" required value="${esc(storeName)}"></div>
        <div class="field"><label>رقم الموبايل</label><input type="tel" name="phone" required value="${esc(phone)}"></div>
        <div class="field"><label>كلمة المرور</label><input type="password" name="password" required minlength="4"></div>
        <button class="btn btn-primary" type="submit">إنشاء الحساب</button>
      </form>
      <div class="auth-switch">عندك حساب بالفعل؟ <a href="/login">تسجيل الدخول</a></div>
      `,
    }));

    if (!name || !storeName || !phone || !password) return fail('من فضلك املأ كل البيانات');
    if (password.length < 4) return fail('كلمة المرور لازم تكون 4 أحرف على الأقل');

    const existing = db.prepare('SELECT id FROM merchants WHERE phone = ?').get(phone);
    if (existing) return fail('في حساب مسجل بالرقم ده بالفعل، جرب تسجيل الدخول');

    const slug = uniqueSlug(storeName);
    const passwordHash = hashPassword(password);
    const info = db
      .prepare('INSERT INTO merchants (name, phone, password_hash, store_name, slug) VALUES (?, ?, ?, ?, ?)')
      .run(name, phone, passwordHash, storeName, slug);

    const token = createSession(info.lastInsertRowid);
    setCookie(res, 'session', token, { maxAge: 60 * 60 * 24 * 60 });
    redirect(res, '/onboarding');
  });

  // ---------- تسجيل الدخول ----------
  router.get('/login', (req, res) => {
    sendHtml(res, 200, authLayout({
      title: 'أهلاً بيك تاني',
      subtitle: 'سجّل دخولك عشان تكمل شغلك في متجرك',
      body: `
      <form method="POST" action="/login">
        <div class="field">
          <label>رقم الموبايل</label>
          <input type="tel" name="phone" required placeholder="01xxxxxxxxx">
        </div>
        <div class="field">
          <label>كلمة المرور</label>
          <input type="password" name="password" required>
        </div>
        <button class="btn btn-primary" type="submit">دخول</button>
      </form>
      <div class="auth-switch">لسه مالكش حساب؟ <a href="/register">سجّل متجرك دلوقتي</a></div>
      `,
    }));
  });

  router.post('/login', async (req, res) => {
    const b = await parseBody(req);
    const phone = (b.phone || '').trim();
    const password = (b.password || '').trim();
    const merchant = db.prepare('SELECT * FROM merchants WHERE phone = ?').get(phone);

    const fail = () => sendHtml(res, 400, authLayout({
      title: 'أهلاً بيك تاني',
      subtitle: 'سجّل دخولك عشان تكمل شغلك في متجرك',
      error: 'رقم الموبايل أو كلمة المرور مش صح',
      body: `
      <form method="POST" action="/login">
        <div class="field"><label>رقم الموبايل</label><input type="tel" name="phone" required value="${esc(phone)}"></div>
        <div class="field"><label>كلمة المرور</label><input type="password" name="password" required></div>
        <button class="btn btn-primary" type="submit">دخول</button>
      </form>
      <div class="auth-switch">لسه مالكش حساب؟ <a href="/register">سجّل متجرك دلوقتي</a></div>
      `,
    }));

    if (!merchant || !verifyPassword(password, merchant.password_hash)) return fail();

    const token = createSession(merchant.id);
    setCookie(res, 'session', token, { maxAge: 60 * 60 * 24 * 60 });
    redirect(res, merchant.onboarded ? '/dashboard' : '/onboarding');
  });

  router.post('/logout', (req, res) => {
    const cookies = parseCookies(req);
    destroySession(cookies.session);
    setCookie(res, 'session', '', { maxAge: 0 });
    redirect(res, '/login');
  });

  // ---------- اختيار المجال (أونبوردنج) ----------
  router.get('/onboarding', (req, res) => {
    if (!req.merchant) return redirect(res, '/login');
    sendHtml(res, 200, authLayout({
      title: 'متجرك بيبيع إيه؟',
      subtitle: 'اختار المجال عشان نظبطلك صفحة البيع والمخزون صح',
      body: `
      <form method="POST" action="/onboarding">
        <div class="cat-grid">
          ${CATEGORIES.map((c, i) => `
            <label class="cat-option">
              <input type="radio" name="category" value="${c.id}" ${i === 0 ? 'checked' : ''}>
              <span class="emoji">${c.emoji}</span>
              <span class="label">${esc(c.label)}</span>
            </label>
          `).join('')}
        </div>
        <div class="field">
          <label>رقم واتساب لاستقبال الأوردرات (اختياري)</label>
          <input type="tel" name="whatsapp" placeholder="01xxxxxxxxx">
          <div class="hint">هيظهر زرار "اطلب الآن" في صفحة البيع بتاعتك ويودّي العميل لواتساب على الرقم ده</div>
        </div>
        <div class="field">
          <label>رابط صفحة الفيسبوك بتاعتك (اختياري)</label>
          <input type="text" name="facebook_url" placeholder="facebook.com/yourpage">
          <div class="hint">هنحط زرار "صفحتنا على فيسبوك" في موقعك يودّي العملاء لصفحتك على طول</div>
        </div>
        <button class="btn btn-primary" type="submit">🚀 إنشاء موقعي الآن</button>
      </form>
      `,
    }));
  });

  router.post('/onboarding', async (req, res) => {
    if (!req.merchant) return redirect(res, '/login');
    const b = await parseBody(req);
    const category = b.category || 'other';
    const whatsapp = (b.whatsapp || '').trim();
    let facebookUrl = (b.facebook_url || '').trim();
    if (facebookUrl && !/^https?:\/\//i.test(facebookUrl)) facebookUrl = `https://${facebookUrl}`;
    db.prepare('UPDATE merchants SET category = ?, whatsapp = ?, facebook_url = ?, onboarded = 1 WHERE id = ?')
      .run(category, whatsapp, facebookUrl, req.merchant.id);
    redirect(res, '/onboarding/done');
  });

  // ---------- شاشة "تم إنشاء الموقع" (أول ما التاجر يدوس زرار الإنشاء) ----------
  router.get('/onboarding/done', (req, res) => {
    if (!req.merchant) return redirect(res, '/login');
    if (!req.merchant.onboarded) return redirect(res, '/onboarding');
    const storeUrl = `${req.headers.host}/store/${req.merchant.slug}`;
    sendHtml(res, 200, authLayout({
      title: '🎉 تم إنشاء موقعك!',
      subtitle: 'موقعك جاهز دلوقتي، وأي منتج تضيفه هيظهر عليه أوتوماتيك',
      success: 'موقعك اتعمل بنجاح',
      body: `
      <div class="link-box mt-8"><span class="url">${storeUrl}</span></div>
      <div class="hint mt-8">انسخ اللينك ده وحطه في بايو صفحة الفيسبوك أو الإنستجرام بتاعتك عشان عملاءك يوصلولك على طول</div>
      <a href="/store/${req.merchant.slug}" target="_blank" class="btn btn-outline mt-16" style="margin-top:14px;">👀 شوف موقعك</a>
      <a href="/dashboard" class="btn btn-primary mt-16" style="margin-top:10px;">ابدأ تضيف منتجاتك ←</a>
      `,
    }));
  });
}

module.exports = { registerRoutes };
